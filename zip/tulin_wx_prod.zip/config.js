var app_global = {
  baseUrl: "https://e.quanzhuyun.com/mapp_port/",
  corpID: "wx4bb5296ea6d435e4",
  langs: "cn",
  androidApkUrl: "https://hotfix.quanzhuejia.com/com_trendzone_tulinerp/android/app.apk",
  iosBrowserUrl: "https://itunes.apple.com/cn/app/%E9%A1%B9%E7%9B%AE%E5%8D%8F%E4%BD%9C%E5%B9%B3%E5%8F%B0/id1453816111?mt=8",
  androidHotCodePath: "https://edemo.quanzhuyun.com/uploadfiles/hotcode/cn_tulin_erp/android",
  iosHotCodePath: "https://edemo.quanzhuyun.com/uploadfiles/hotcode/cn_tulin_erp/ios",
  fileBaseUrl: "https://edemo.quanzhuyun.com/uploadfiles/qjjfwpt_dev/temp/",
  logoUrl:"assets/images/login/logo.png",
  isApprovedClose: false,
};